Pour executer le programme:

Lancer VerifChemPers.jar.

ou

Compiler les fichiers .java et lancer la classe Main.